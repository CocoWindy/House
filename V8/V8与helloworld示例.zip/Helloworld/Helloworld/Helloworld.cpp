// Helloworld.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <v8.h>

using namespace v8;

int _tmain(int argc, _TCHAR* argv[])
{
    // Get the default Isolate created at startup.
    Isolate* isolate = Isolate::GetCurrent();

    // Create a stack-allocated handle scope.
    HandleScope handle_scope(isolate);

    // Create a new context.
    Persistent<Context> context = Context::New();

    // Enter the created context for compiling and
    // running the hello world script. 
    Context::Scope context_scope(context);

    // Create a string containing the JavaScript source code.
    Handle<String> source = String::New("'Hello' + ', World!'");

    // Compile the source code.
    Handle<Script> script = Script::Compile(source);

    // Run the script to get the result.
    Handle<Value> result = script->Run();

    // Dispose the persistent context.
    context.Dispose(isolate);

    // Convert the result to an ASCII string and print it.
    String::AsciiValue ascii(result);
    printf("%s\n", *ascii);
    return 0;

}

